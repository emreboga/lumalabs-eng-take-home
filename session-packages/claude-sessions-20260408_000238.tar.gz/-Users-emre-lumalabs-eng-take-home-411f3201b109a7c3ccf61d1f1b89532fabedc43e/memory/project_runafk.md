---
name: RunAFK Project
description: Async Slack-based coding agent system. Relay on Railway + local Docker agent.
type: project
---

Building "RunAFK" for Luma take-home problem #2 (Work With Coding Agents While Away From Your Desk).

Two components: runafk-relay (Railway, Slack Bolt, Postgres) and runafk-agent (local Docker, Claude Code CLI).

**Why:** Developer wants to manage GitHub issue → plan → implement → PR workflow async from Slack while away from laptop.

**How to apply:** All architectural decisions below are finalized. Do not re-litigate them.

## Current State (as of 2026-04-07)

Both checkpoints verified and committed:
- CP1: Slack → Relay → Slack (echo) ✓
- CP2: Slack → Relay → Agent → Relay → Slack (stub) ✓

Relay deployed at: https://runafk-relay-production.up.railway.app
Relay Railway project ID: c5034645-a13a-47e8-8e27-1ef80c7539e2

**Next step: Phase 1 — Add Postgres to Railway project (via dashboard, CLI auth expired), then wire up DB.**

## Implementation Phases

### Phase 1 — Postgres (relay) [NOT STARTED]
- Add Postgres via Railway dashboard → auto-injects DATABASE_URL
- Schema: agents (slack_user_id, token_hash, is_active, created_at), tasks (id, slack_user_id, issue_number, type, status, plan_text, created_at)
- Migrate /register from in-memory to DB

### Phase 2 — Shared types [NOT STARTED]
- Full task payloads: list, plan, post_plan, implement
- Checkpoint type: started | code_completed | testing | tests_passed | pr_opened | error

### Phase 3 — Relay commands [NOT STARTED]
- /list → send task to agent → post result to Slack
- /plan #123 → send to agent → receive plan → Approve/Reject buttons → on approve send post_plan to agent
- /implement #123 → send to agent → receive checkpoints → post each to Slack → final PR link
- Relay posts "working on it..." immediately after successfully forwarding to agent

### Phase 4 — Agent task execution [NOT STARTED]
- Task router replacing stub handler
- list: GH API → fetch assigned open issues → return formatted
- plan: clone repo → Claude Code CLI → return plan text
- post_plan: post plan as GH issue comment
- implement: fetch issue + plan comment → clone → branch runafk/issue-N → Claude Code CLI → discover & run tests → push → open PR → return PR URL

## Architecture

### runafk-relay (Railway, Node.js/TypeScript)
- Slack Bolt app (HTTP mode, not socket), DM channel only
- Slash commands: /register, /list, /plan #123, /implement #123 (extensible)
- WebSocket server — multiple agents, one per Slack user, Bearer token auth
- Routing: Slack user_id → token_hash → active WS connection (Postgres lookup)
- Agent offline → immediate "agent is offline" reply
- Postgres for token registry and task persistence
- Sends raw task data to agent; agent owns prompt construction and all GitHub operations

### Communication boundaries
- Relay: Slack ↔ Agent routing only. No GitHub API calls, no Claude.
- Agent: owns ALL external integrations — GitHub API, git operations, Claude Code CLI.
- GITHUB_TOKEN lives only in agent .env

### Security
- Tokens stored SHA-256 hashed in Postgres, never plaintext
- WSS only: reject plain ws:// connections
- One connection per token: reject or disconnect duplicates
- Auth headers never logged
- is_active flag per token for revocation without restart

### runafk-agent (Local Docker, Node.js/TypeScript)
- Connects outbound to relay via WSS on startup, auto-reconnects every 5s
- Receives raw task data, constructs prompt, runs Claude Code CLI (ANTHROPIC_API_KEY)
- All GitHub operations via GITHUB_TOKEN
- Posts checkpoints to relay: started → code completed → testing → tests passed → pr_opened
- On test failure or any error: post error to Slack DM, stop. Never post errors to GitHub.

### Git/GitHub flow
- Env vars: AGENT_REPO (e.g. emreboga/my-repo), GITHUB_TOKEN, ANTHROPIC_API_KEY, AGENT_TOKEN
- Clone repo → branch runafk/issue-123 → implement → test → push → open PR
- Discover test command from root config (prefer CI command), run once
- Workspace cleaned after PR push
- Commits: developer GH identity + AI-generated note

### Command flows

**/list:** relay → agent (GH API: open issues assigned to token owner) → relay → Slack

**/plan #123:**
1. Relay sends plan task to agent
2. Agent: clone repo + Claude Code CLI → plan text
3. Relay: post plan to Slack with Approve / Reject buttons
4. On Approve: relay sends post_plan task to agent (plan text + issue number)
5. Agent: post plan as GH issue comment

**/implement #123:**
1. Relay sends implement task to agent
2. Agent: check GH issue for approved plan comment; if none → return error "run /plan first"
3. If found: clone → branch runafk/issue-N → Claude Code CLI → test → push → open PR
4. Agent sends checkpoints: started → code completed → testing → tests passed → pr_opened
5. Relay posts each checkpoint to Slack DM

## Naming
- Slack app: RunAFK
- Branch prefix: runafk/issue-123
- Relay service: runafk-relay
- Agent: runafk-agent
- Relay URL: https://runafk-relay-production.up.railway.app
