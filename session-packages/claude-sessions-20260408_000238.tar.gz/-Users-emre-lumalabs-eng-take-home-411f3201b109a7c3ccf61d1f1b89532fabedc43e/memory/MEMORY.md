# Memory Index

- [RunAFK Project](project_runafk.md) — Slack-based async coding agent system; relay + agent architecture, all design decisions finalized
